<?php

$conn = mysqli_connect('localhost','root','','body_tone_db');

?>
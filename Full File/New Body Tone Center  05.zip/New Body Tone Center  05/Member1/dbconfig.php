<?php

$connection = mysqli_connect("localhost","root","","body_tone_db");

?>
<main>
	<div class="head-title">
		<div class="left">
			<h1>Settings</h1>

		</div>

	</div>

	<ul class="box-info">
		<li>
		<i class='bx bxs-cog'></i>
			<span class="text">
				<h3>View Details</h3>
				<p>View  details </p>
			</span><br>
			<td>
				<a class='btn info btn-sm' href='SettingProfile_View.php?id=1'>View</a>

			</td>
		</li>
		<li>
			<i class='bx bxs-cog'></i>
			<span class="text">
				<h3>Profile Change</h3>
				<p>Change your Account Details </p>
			</span>
			<td>
				<a class='btn warning btn-sm' href='SettingProfile_Edit.php?id=1'>Change</a>

			</td>
		</li>
		<!-- <li>
		<i class='bx bxs-cog'></i>
			<span class="text">
				<h3>Password Change</h3>
				<p>Edit your Change Password  </p>
			</span>
			<td>
				<a class='btn danger btn-sm' href='SettingPassword_Edit.php?id=1'>Update</a>

			</td>
		</li> -->
		
		
	</ul>
	<ul class="box-info">

	</ul>
	<ul class="box-info">
		<li style="background-color: transparent;">
		
	</ul>



</main>
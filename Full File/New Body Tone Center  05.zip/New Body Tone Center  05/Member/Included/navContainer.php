<nav>
	<i class='bx bx-menu'></i>
	<h3><span style="color: white;">Member Dashboard</span></h3>
	<form action="#">
		<div class="form-input">

		</div>
	</form>

	<a href="#" class="notification">
		<i class='bx bxs-bell'></i>
		<span class="num">8</span>
	</a>
	<!-- <a href="#" class="profile">
		<img src="img/people.png">
	</a> -->
	<a href="">
		<h5>Hi, <span style="color: red;"><?php echo $_SESSION['member_name'] ?></span></h5>		
	
</nav>